﻿using Microsoft.AspNetCore.Mvc;

namespace testing_Front.Controllers
{
    public class ErrorCredentialsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
